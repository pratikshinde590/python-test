-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acts`
--

DROP TABLE IF EXISTS `acts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `details_text` longtext NOT NULL,
  `photo` varchar(255) NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category` int NOT NULL,
  `sub_category` int NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acts`
--

LOCK TABLES `acts` WRITE;
/*!40000 ALTER TABLE `acts` DISABLE KEYS */;
INSERT INTO `acts` VALUES (35,'Notification dated 27.1.2023','','',1,'2023-09-08 14:10:59','2023-09-08 14:10:59',4,0,'admin/homepage_docs/acts/1694162459Notification_dated_27.1.2023.pdf'),(36,'Notifications dated 13.2.2023','','',1,'2023-09-08 14:11:44','2023-09-08 14:11:44',4,0,'admin/homepage_docs/acts/1694162504Notifications_dated_13.2.2023.pdf'),(37,'Amendment in the notification of establishment of NDIAC dated 13.2.2023','','',1,'2023-09-08 14:14:56','2023-09-08 14:14:56',4,0,'admin/homepage_docs/acts/1694162696Amendment_in_the_notification_of_establishment_of_NDIAC.pdf'),(38,'Notification dated 22.2.2023','','',1,'2023-09-08 14:16:02','2023-09-08 14:16:02',4,0,'admin/homepage_docs/acts/1694162762Notification_dated_22.2.2023.pdf'),(39,'Bar Council of India- Foreign Lawyers can appear in the International Commercial Arbitration (19.3.2023)','','',1,'2023-09-08 14:16:44','2023-09-08 14:16:44',4,0,'admin/homepage_docs/acts/1694162804Bar-Council-of-India-Foreign-Lawyers-can-appear-in-the-International-Commercial-Arbitration-(19.3.2023).pdf'),(40,'India International Arbitration Centre (Conduct of Arbitration) Regulations, 2023 (English Version)','','',1,'2023-09-08 14:18:04','2023-09-08 14:18:04',3,0,'admin/homepage_docs/acts/1694162884India_International_Arbitration_Centre_(Conduct_of_Arbitration)_Regulation,_2023_(English_Version).pdf'),(41,'The India International Arbitration Centre (Conduct of Arbitration) Regulations, 2023.','','',1,'2023-09-08 14:18:48','2023-09-08 14:18:48',3,0,'admin/homepage_docs/acts/1694162928India_International_Arbitration_Centre_(Conduct_of_Arbitration)_Regulations,_2023.pdf'),(42,'The India International Arbitration Centre (Criteria for Admission to the panel of arbitrators) Regulations, 2023','','',1,'2023-09-08 14:19:23','2023-09-08 14:19:23',3,0,'admin/homepage_docs/acts/1694162963Criteria-for-Admission-to-the-panel-of-arbitrators.pdf'),(43,'The India International Arbitration Centre (Transaction of Business) Regulations, 2023','','',1,'2023-09-08 14:20:02','2023-09-08 14:20:02',3,0,'admin/homepage_docs/acts/1694163002IIAC.pdf'),(44,'IIAC (Form of Annual Statement of Accounts) Rules, 2022','','',1,'2023-09-08 14:21:30','2023-09-08 14:21:30',2,0,'admin/homepage_docs/acts/1694163090IIAC-(Form-of-Annual-Statement-of-Accounts)-Rules,-2022.pdf'),(45,'IIAC (Number of Posts and Recruitment of Registrar, Counsel and other Officers and Employees) Rules, 2022','','',1,'2023-09-08 14:22:19','2023-09-08 14:22:19',2,0,'admin/homepage_docs/acts/1694163139IIAC(Number-of-Posts-and-Recruitment-of-Registrar,Counsel-and-other-officers-and-employees)Rules,2022.pdf'),(46,'IIAC (Terms and Conditions and the Salary and allowances payable to Chairperson and Full-time Members) Rules, 2022','','',0,'2023-09-08 14:22:56','2023-09-08 14:22:56',2,0,'admin/homepage_docs/acts/1694163176IIAC(Terms-and-Conditions-and-the-Salary-and-allowances-payable-to-Chairperson-and-Full-time-Members)Rules,2022.pdf'),(47,'IIAC (Travelling and other Allowances Payable to Part-time Members) Rules, 2023','','',1,'2023-09-08 14:24:34','2023-09-08 14:24:34',2,0,'admin/homepage_docs/acts/1694163274IIAC-(Travelling-and-other-Allowances-Payable-to-Part-time-Members)Rules,2023.pdf'),(48,'India International Arbitration Centre Act, 2019 (Act No. 17 of 2019, amended by Act No. 23 of 2022)','','',1,'2023-09-08 14:26:18','2023-09-08 14:26:18',1,1,'admin/homepage_docs/acts/1694163378India_International_Arbitration_Centre_Act_2019.pdf'),(49,'The New Delhi International Arbitration Centre Act, 2019 (Act No. 17 of 2019)','','',0,'2023-09-08 14:27:05','2023-09-08 14:27:05',1,1,'admin/homepage_docs/acts/1694163425Act_No._17_of_2019.pdf'),(50,'The New Delhi International Arbitration Centre (Amendment) Act, 2022 (Act No. 23 of 2022)','','',1,'2023-09-08 14:28:23','2023-09-08 14:28:23',1,1,'admin/homepage_docs/acts/1694163503Act_No._23_of_2022.pdf'),(51,'The Arbitration and Conciliation Act, 1996 (Act No. 26 of 1996 as updated on 12.3.2021)','','',1,'2023-09-08 14:29:20','2023-09-08 14:29:20',1,2,'admin/homepage_docs/acts/1694163560Act_No._26_of_1996_as_updated_on_27.01.2023.pdf'),(52,' Arbitration and Conciliation (Amendment) Act, 2015 (Act No. 3 of 2016)','','',1,'2023-09-08 14:30:12','2023-09-08 14:30:12',1,2,'admin/homepage_docs/acts/1694163612Arbitration_and_Concilition__Act_2015.pdf'),(53,'Arbitration and Conciliation (Amendment) Act, 2019 (Act No. 33 of 2019)','','',1,'2023-09-08 14:30:48','2023-09-08 14:30:48',1,2,'admin/homepage_docs/acts/1694163648Arbitration_and_Concilition_Act_No.33_of_2019.pdf'),(54,'Jammu and Kashmir Reorginsation Act, 2019 (Act No. 34 of 2019)','','',0,'2023-10-05 15:27:36','2023-10-05 15:27:36',1,2,'admin/homepage_docs/acts/1694163689Jammu_and_Kashmir_Reorginsation_Act,_2019_(Act_No._34_of_2019).pdf'),(55,'Arbitration and Conciliation (Amendment) Act, 2021 (Act No. 3 of 2021) new','','',0,'2023-10-05 15:23:59','2023-10-05 15:23:59',1,2,'admin/homepage_docs/acts/1694163724Arbitration_and_Concilition_(Amendment)_2021.pdf_(Act_No._3_of_2021.pdf'),(56,'Testing Practice directions - This is a testing Statutes','','',1,'2023-10-30 11:33:30','2023-10-30 11:33:30',1,1,'admin/homepage_docs/acts/1698645810invite.ics');
/*!40000 ALTER TABLE `acts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:17:45
