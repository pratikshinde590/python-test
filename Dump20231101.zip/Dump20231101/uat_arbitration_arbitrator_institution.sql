-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arbitrator_institution`
--

DROP TABLE IF EXISTS `arbitrator_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arbitrator_institution` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type_id` int NOT NULL DEFAULT '0',
  `period_of_empanelment` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=816 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arbitrator_institution`
--

LOCK TABLES `arbitrator_institution` WRITE;
/*!40000 ALTER TABLE `arbitrator_institution` DISABLE KEYS */;
INSERT INTO `arbitrator_institution` VALUES (2,1,'Shashank','2023-05-25',0,55),(3,4,'test','2023-05-10',0,10),(4,3,'Abbba jaba','1970-01-01',0,50),(5,2,'high court delhi','2023-05-12',0,9),(6,11,'University','2010-02-02',0,23),(7,12,'sadfsf','2023-05-09',0,43),(12,15,'erty','2023-05-03',0,67),(13,16,'iiiittt','2023-05-10',0,9),(16,21,'INDIAN COUNCIL OF ARBITRATION','2018-04-12',0,5),(20,30,'Mediation and Arbitration Centre  High Court of Telangana','2022-06-09',0,1),(36,34,'test data','2023-05-09',0,2),(37,34,'test ','2023-05-26',0,4),(54,33,'MADRAS HIGH COURT ARBITRATION CENTRE','2022-03-31',0,2),(55,32,'abc','2023-05-01',0,10),(56,32,'abc','2023-05-02',0,5),(59,37,'test inst.','2023-05-18',0,12),(60,37,'test inst 2','2023-05-26',0,33),(63,39,'Delhi International Arbitration Centre','2021-07-12',0,2),(64,39,'Indian Council of Arbitration','2012-06-05',0,11),(65,39,'Standing Conference of Public Enterprises','2014-08-20',0,9),(66,39,'National Stock Exchange','2016-10-21',0,7),(67,39,'London Court of International Arbitration','2019-12-31',0,4),(74,24,'Delhi International Arbitration Centre','2023-03-01',0,1),(75,24,'Hyderabad Arbitration Centre','2021-02-17',0,2),(76,24,'Indian Road Congress','2021-03-12',0,2),(77,24,'Construction Industry Arbitration Council','2019-10-25',0,4),(78,24,'Indian Council of Arbitration','2019-01-28',0,4),(94,36,'abc','2023-05-30',0,5),(106,52,'Madras High Court Arbitration Centre','2021-06-30',0,2),(153,51,'abc','2024-05-30',0,5),(157,42,'Indian Council of Arbitration (FICCI) including Maritime Arbitrations','2018-08-02',0,5),(158,42,'SCOPE Forum of Conciliation & Arbitration (SFCA) ','2020-09-02',0,3),(159,42,'RITES','2020-09-02',0,3),(160,42,'Indian Oil Corporation Limited','2020-09-02',0,3),(161,42,'Steel Authority of India Limited','2020-09-02',0,3),(323,67,'Delhi International Arbitration Centre Delhi High Court.','2021-07-12',0,20),(391,58,'The Institute of Chartered Accountants of India','2023-01-15',0,25),(392,58,'Centre for Alternate Dispute Resolution Excellence CADRE','2022-09-29',0,15),(393,58,'Indian Council of Arbitration','2023-03-04',0,15),(394,58,'Delos Dispute Resolutions France','2022-12-12',0,15),(395,58,'The Arbitration and Dispute Resolution Institute of Oslo Chamber of Commerce Norway','2022-12-19',0,10),(396,58,'London Court of International Arbitration (LCIA)','2023-01-12',0,10),(397,58,'Singapore International Arbitration Centre (SIAC)','2023-01-25',0,10),(398,58,'WIPO Arbitration and Mediation Center Switzerland','2023-01-26',0,10),(399,58,'Construction Industry Arbitration Council India (CIAC)','2023-02-06',0,10),(400,58,'Vienna International Arbitration Centre Austria (VIAC) ','2023-02-10',0,10),(401,58,'SCC Arbitration Institute of the Stockholm Chamber of Commerce Sweden (SCC)','2023-02-13',0,10),(402,58,'Venice Chamber of Arbitration Italy','2023-02-24',0,10),(403,58,'The Danish Institute of Arbitration','2023-02-01',0,10),(404,58,'Thai Arbitration Institute (TAI)','2023-01-18',0,10),(405,58,'Cyprus Eurasia Dispute Resolution & Arbitration Centre (CEDRAC)','2023-03-01',0,10),(406,58,'Qatar International Center for Conciliation and Arbitration (QICCA)','2023-04-03',0,10),(407,58,'Cayman International Mediation and Arbitration Centre (CI-MAC) ','2023-03-06',0,10),(408,58,'International Centre for Arbitration & Mediation in Kampala (ICAMEK)','2023-04-01',0,10),(409,58,'Council for National and International Commercial Arbitration [CNICA]','2023-04-11',0,10),(410,58,'Cotton Association of India (CAI)','2023-02-24',0,10),(411,58,'KCCI Arbitration Centre of the Kanara Chamber of Commerce & Industry','2023-04-11',0,10),(412,58,'Indian Dispute Resolution Centre, India (IDRC)','2023-01-12',0,10),(422,72,'Indian Council of Arbitration','2018-11-14',0,4),(431,13,'Indian Council of Arbitrators','2023-03-04',0,1),(432,13,'Delhi Development Authority','2022-11-29',0,1),(433,13,'Delhi State Industrial & Infrastructure Corporation','2022-03-31',0,1),(434,13,'Municipal Corporation of Delhi','2022-03-24',0,1),(506,95,'ICADR','2016-03-01',0,7),(507,95,'INDIAN ROADS CONGRESS','2023-06-01',0,7),(508,95,'ICA','2015-02-09',0,8),(509,95,'INDIAN INSTITUTE OF TECHNICAL ARBITRATORS','2017-03-01',0,6),(510,95,'SAROD PORTS','2018-06-13',0,5),(520,114,'KOVISE FOUNDATION CONFLICT RESOLUTION INTERNATIONAL','2020-07-01',0,1),(521,114,'KOVISE FOUNDATION CONFLICT RESOLUTION INTERNATIONAL','2021-10-01',0,1),(522,40,'Delhi International Arbitration Center','2018-09-13',0,5),(523,40,'Madras High Court Arbitration Center','2018-08-14',0,5),(524,40,'Indian Council of Arbitration','2018-10-01',0,5),(525,40,'SCOPE Arbitration Center','2018-09-03',0,5),(526,40,'BHEL','2019-01-28',0,4),(527,40,'NHPC','2019-01-01',0,4),(528,40,'Airport Authority of India','2022-07-22',0,1),(547,118,'Indian Council of Arbitration','2019-09-21',0,15),(548,118,'SCOPE','2019-09-20',0,5),(549,118,'PGCIL','2017-08-03',0,10),(550,118,'NHPC','2023-06-02',0,3),(551,118,'Ministry of Power CCIE 3','2022-03-22',0,3),(552,60,'abc','2023-06-02',0,5),(553,60,'abc','2023-06-03',0,5),(554,60,'abc','2024-05-30',0,5),(576,121,'ICA','2010-06-16',0,20),(581,111,'Madras High Court Arbitration centre  Chennai','2021-07-02',0,3),(582,111,'Indian Council of Arbitration','2019-09-15',0,4),(583,111,'Nani Palkhivala Arbitration centre','2020-07-15',0,3),(584,111,'Standing Conference of Public Enterprises','2013-03-01',0,1),(585,111,'SICCI Centre for ADR','2023-03-17',0,1),(586,126,'Singapore International Arbitration Centre ','2023-06-01',0,5),(606,59,'Indian Council of Arbitration New Delhi','2020-11-06',0,2),(607,59,'Madhya Pradesh Domestic & International Arbitration Centre','2020-10-20',0,2),(608,28,'abc','2021-12-07',0,3),(609,28,'abc','2019-09-30',0,3),(621,135,'Singapore International Arbitration Centre ','2023-06-05',0,5),(622,135,'Singapore International Arbitration Centre ','2023-06-01',0,5),(624,46,'Delhi International Arbitration Centre','2021-07-12',0,1),(625,143,'INDIAN COUNCIL OF ARBITRATION','2005-07-18',0,17),(626,143,'STANDING CONFERENCE OF PUBLIC ENTERPRISES','2014-08-20',0,8),(627,142,'CHANDIGARH ARBITRATION CENTRE PUNJAB & HARYANA HIGH COURT','2020-09-09',0,3),(628,142,'INDIAN COUNCIL OF ARBITRATION ','2020-11-19',0,5),(629,142,'INDIAN INSTITUTE OF ARBITRATION & MEDIATION','2020-12-23',0,5),(630,142,'MADHYA PRADESH ARBITRATION CENTRE HIGH COURT JABALPUR','2021-03-10',0,5),(631,142,'SCOPE FORUM OF CONCILIATION & ARBITRATION','2023-03-02',0,5),(632,147,'Australian Centre for International Commercial Arbitration','2021-11-17',0,2),(633,147,'Singapore International Arbitration Centre  Reserve List','2022-12-08',0,1),(634,147,'Asian Centre for International Arbitration','2022-03-08',0,1),(662,35,'TEST institution','2023-06-06',0,12),(663,35,'test institute2','2023-06-07',0,14),(664,153,'Delhi International Arbitration Centre','2023-03-01',0,5),(665,153,'Indian Council of Arbitration','2019-11-15',0,10),(666,153,'Construction Industry Arbitration Council','2018-07-06',0,5),(667,153,'Indian Institute of Technical Arbitrators','2019-10-19',0,10),(668,155,'IIT Arb ','2021-03-08',0,2),(669,117,'Bengaluru Arbitration Centre','2022-06-03',0,1),(670,117,'Delhi International Arbitration Centre','2022-08-03',0,1),(671,124,'Madras High Court Arbitration Centre','2020-06-11',0,5),(681,47,'Indian Council of Arbitration','2022-04-27',0,1),(682,47,'Delhi International Arbitration Centre','2022-04-13',0,1),(683,47,'Society for Affordable Redressal of Disputes SAROD ','2022-09-02',0,1),(684,47,'Yamuna Expressway Industrial Development Authority','2023-01-11',0,1),(708,87,'Institution of Engineers India','2019-07-05',0,5),(717,89,'Delhi International Arbitration Centre','2018-07-12',0,5),(718,89,'Indian Council of Arbitration','2018-12-03',0,4),(734,166,'Bombay High Court ','2018-08-06',0,5),(737,180,'Indian Council of Arbitration','2011-05-09',0,25),(753,182,'iiac','2023-06-08',0,8),(754,182,'iiac2','2023-06-15',0,9),(755,165,'Indian council of Arbitration','2004-08-25',0,19),(774,177,'DELHI ARBITRATION CENTER NEW DELHI','2023-04-06',0,1),(775,177,'DELHI INTERNATIONAL ARBITRATION CENTER','2022-07-25',0,1),(776,177,'BOMBAY HIGH COURT MUMBAI','2022-12-07',0,1),(777,177,'ANDHRA PRADESH HIGH COURT','2022-11-24',0,1),(778,177,'PUNJAB AND HARYANA HIGH COURT','2021-11-22',0,3),(779,177,'ALLAHABAD HIGH COURT','2021-06-29',0,1),(780,184,'Delhi International Arbitration Centre','2021-07-12',0,2),(782,175,'Indian Council of Arbitration  ','2020-12-22',0,3),(784,185,'Asian International Arbitration Centre','2023-06-12',0,3),(786,159,'Singapore International Arbitration Centre ','2023-06-04',0,5),(815,27,'Capegemini','2000-05-03',0,2);
/*!40000 ALTER TABLE `arbitrator_institution` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:17:05
