-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event_guests`
--

DROP TABLE IF EXISTS `event_guests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_guests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `profession` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `event_role` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `profile_img_type` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `profile_img_name` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `profile_img_url` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_guests`
--

LOCK TABLES `event_guests` WRITE;
/*!40000 ALTER TABLE `event_guests` DISABLE KEYS */;
INSERT INTO `event_guests` VALUES (1,1,'Hon\'ble Mr. Justice Surya Kant','Judge, Supreme Court of India','Chief Guest','image/jpeg','1695156182suryakant.jpg','admin/homepage_docs/event/1695156182suryakant.jpg','2023-09-20 02:13:02','2023-09-20 02:13:53'),(2,1,'Hon\'ble Mr. Justice Satish Chandra Sharma','Chief Justice, Delhi High Court','Guest of Honour','image/jpeg','1695156225satishchandra.jpg','admin/homepage_docs/event/1695156225satishchandra.jpg','2023-09-20 02:13:45','2023-09-20 02:13:54'),(4,2,'Hon\'ble Mr. Justice Surya Kant','Test','Guest','image/jpeg','1695838437WIN_20230701_17_34_51_Pro.jpg','admin/homepage_docs/event/1695838437WIN_20230701_17_34_51_Pro.jpg','2023-09-27 23:43:57','2023-09-27 23:44:10'),(6,3,'Abcd','XYZ','Co-ordinator','image/png','1696844970A-classic-GhostScript-SVG-example.png','admin/homepage_docs/event/1696844970A-classic-GhostScript-SVG-example.png','2023-10-09 15:19:30','2023-10-09 15:23:11'),(7,3,'Mr. Devi Prasad','Advocate','Presentator','image/jpeg','1696845053download.jpg','admin/homepage_docs/event/1696845053download.jpg','2023-10-09 15:20:53','2023-10-09 15:23:12'),(8,3,'.','.','.','image/png','16968450911682930432logo_xs.png','admin/homepage_docs/event/16968450911682930432logo_xs.png','2023-10-09 15:21:31','2023-10-09 15:23:13'),(10,3,'123','wasd','Organiser','image/jpeg','1696845177pngtree-svg-file-document-icon-png-image_897178.jpg','admin/homepage_docs/event/1696845177pngtree-svg-file-document-icon-png-image_897178.jpg','2023-10-09 15:22:57','2023-10-09 15:23:14'),(11,4,'Mr. XYZ','Law Maker','Guest Lecturer','image/webp','16968473221600w-kpZhUIzCx_w.webp','admin/homepage_docs/event/16968473221600w-kpZhUIzCx_w.webp','2023-10-09 15:58:42','2023-10-09 16:03:32'),(13,6,'Sierra','Law Scholar','Presentator','image/jpeg','1696848188images.jpg','admin/homepage_docs/event/1696848188images.jpg','2023-10-09 16:13:08','2023-10-09 16:14:53'),(15,6,'Ms. ABC','Addtl Judge','GUest','image/webp','16968482851600w-m_-ss6tcQlQ.webp','admin/homepage_docs/event/16968482851600w-m_-ss6tcQlQ.webp','2023-10-09 16:14:45','2023-10-09 16:14:54'),(17,9,'Mr. ABC','Professor','Chairperson','image/jpeg','1697121835download.jfif','admin/homepage_docs/event/1697121835download.jfif','2023-10-12 20:13:55','2023-10-12 20:15:18'),(18,9,'Mr. XYZ','Professor 2','Speaker','image/jpeg','16971218782mb-01439.jpg','admin/homepage_docs/event/16971218782mb-01439.jpg','2023-10-12 20:14:38','2023-10-12 20:15:19'),(19,9,'Mr.JKL','Professor','Speaker 2','image/jpeg','1697121909photo-1579393329936-4bc9bc673651.jfif','admin/homepage_docs/event/1697121909photo-1579393329936-4bc9bc673651.jfif','2023-10-12 20:15:09','2023-10-12 20:15:19'),(20,10,'Mr. ABC','Test','Test','image/jpeg','1697122238download.jfif','admin/homepage_docs/event/1697122238download.jfif','2023-10-12 20:20:38','2023-10-12 20:20:46'),(22,11,'Shivaay','Advocate','Arbitrator','image/jpeg','1697458692download_(1).jpg','admin/homepage_docs/event/1697458692download_(1).jpg','2023-10-16 17:48:12','2023-10-16 17:48:28'),(25,12,'Test','Test','Test','image/jpeg','1697464767download.jfif','admin/homepage_docs/event/1697464767download.jfif','2023-10-16 19:29:27','2023-10-16 19:29:50'),(26,12,'Test','test','Test','image/jpeg','1697464784photo-1579393329936-4bc9bc673651.jfif','admin/homepage_docs/event/1697464784photo-1579393329936-4bc9bc673651.jfif','2023-10-16 19:29:44','2023-10-16 19:29:50'),(27,13,'Mr Vivek','Advocate','Guest','image/jpeg','1698238062profile.jpg','admin/homepage_docs/event/1698238062profile.jpg','2023-10-25 18:17:42','2023-10-25 18:17:53'),(28,13,'Mr Sandeep','Judge','Guest','image/jpeg','1698238227profile.jpg','admin/homepage_docs/event/1698238227profile.jpg','2023-10-25 18:20:27','2023-10-25 18:20:37'),(29,14,'Pranit','Prod Manager','None','image/jpeg','1698340909download.jfif','admin/homepage_docs/event/1698340909download.jfif','2023-10-26 22:51:49','2023-10-26 22:52:15'),(30,14,'Test','Test','Test','image/jpeg','1698340928download_(1).jfif','admin/homepage_docs/event/1698340928download_(1).jfif','2023-10-26 22:52:08','2023-10-26 22:52:16'),(31,15,'Mr. Vikram','Professor','Arbitrator','image/webp','16984104861600w-kpZhUIzCx_w.webp','admin/homepage_docs/event/16984104861600w-kpZhUIzCx_w.webp','2023-10-27 18:11:26','2023-10-27 18:13:35'),(32,15,'Mrs. Sheila','Attorney','Moderator','image/jpeg','1698410558download_(1).jpg','admin/homepage_docs/event/1698410558download_(1).jpg','2023-10-27 18:12:38','2023-10-27 18:13:36'),(33,16,'Shrini Shrinivas','fsfsdf','fsdfs',NULL,NULL,NULL,'2023-10-29 17:27:20','2023-10-29 17:27:30'),(34,17,'sanil nayak','QA','QA',NULL,NULL,NULL,'2023-10-30 11:54:09','2023-10-30 11:55:31'),(35,NULL,'XYZ','ABC','TESTING','image/jpeg','1698649996Sky7.jpg','admin/homepage_docs/event/1698649996Sky7.jpg','2023-10-30 12:43:16','2023-10-30 12:43:16');
/*!40000 ALTER TABLE `event_guests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:23:56
