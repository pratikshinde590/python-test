-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arbitrators_meeting`
--

DROP TABLE IF EXISTS `arbitrators_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arbitrators_meeting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `arbitrators_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `is_online` varchar(100) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `start_time` varchar(20) NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `message` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` smallint NOT NULL DEFAULT '0',
  `is_deleted` smallint NOT NULL DEFAULT '0',
  `created_by` bigint NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `meeting_id` varchar(100) DEFAULT NULL,
  `passcode` varchar(100) DEFAULT NULL,
  `meeting_view_id` varchar(250) NOT NULL,
  `meeting_view_email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arbitrators_meeting`
--

LOCK TABLES `arbitrators_meeting` WRITE;
/*!40000 ALTER TABLE `arbitrators_meeting` DISABLE KEYS */;
INSERT INTO `arbitrators_meeting` VALUES (1,199,'Online','Online','2023-06-30 00:00:00',NULL,'12:16:PM','12:16:PM','test meeting',0,0,198,'2023-06-29 06:46:13','c3l7mT','JQBUN5YB2s','',NULL),(2,1,'In-Person','In-Person','2023-06-13 00:00:00',NULL,'4:42:PM','2:42:PM','dkjhfgdbkjbfdsjfgesdkjbdaskjfhekfajksbfkeajhfeksahkas',0,0,281,'2023-07-01 09:14:34','JCQXAo','jaRiF3RDFR','',NULL),(3,199,'Online','Online','2023-05-31 00:00:00',NULL,'10:11:PM','4:11:PM','sasdas',0,0,281,'2023-07-01 10:41:44','cfQa58','hzT1aoWwGq','',NULL),(4,176,'Online','Online','2023-07-04 00:00:00',NULL,'3:58:AM','4:58:AM','Test',0,0,10,'2023-07-02 05:00:42','Ok6Rr3','16IwY0rG8D','',NULL),(5,282,'Online','Online','2023-07-03 00:00:00',NULL,'7:56:AM','8:56:AM','test',0,0,10,'2023-07-02 07:59:25','2FdjHg','nSMo0YSIqq','',NULL),(6,282,'Online','Online','2023-07-03 00:00:00',NULL,'9:48:AM','10:48:AM','test',0,0,10,'2023-07-02 09:49:48','d8IoX1','X8t840MaSR','',NULL),(7,176,'Online','Online','2023-07-04 00:00:00',NULL,'10:13:PM','11:13:PM','hi shailendra',0,0,10,'2023-07-02 12:14:20','v2hHcG','XDRwYh8BLL','',NULL),(8,20,'Online','Online','2023-06-08 00:00:00',NULL,'6:55:PM','8:55:PM','cshvdshjvds',0,0,10,'2023-07-02 15:26:11','4PC9c5','uZikVU0XnJ','',NULL),(9,199,'Online','Online','2023-07-04 00:00:00',NULL,'2:25:PM','5:25:PM','HI',0,0,281,'2023-07-04 11:57:08','3W5Vhq','sH85LTjTcp','',NULL),(10,87,'Online','Online','2023-07-07 00:00:00',NULL,'3:10:PM','3:10:PM','Hiubsusgdus\nnjhsguds\\hvbjhvdhsj',0,0,10,'2023-07-07 09:41:12','DJozpj','hvtkkTPalu','',NULL),(11,159,'Online','Online','2023-07-21 00:00:00',NULL,'9:09:PM','9:09:PM','Hi',0,0,197,'2023-07-20 15:42:24','XHnSb3','9ZGu9zIdbr','',NULL),(12,79,'Online','Online','2023-08-02 00:00:00',NULL,'11:20:AM','11:20:AM','hi',0,0,3,'2023-08-01 06:21:00','mCqxQj','E58Rq2WrBD','',NULL),(13,284,'Online','Online','2023-08-07 00:00:00',NULL,'2:00:PM','3:55:PM','hello I\'m testing this',0,0,3,'2023-08-07 08:32:27','qfbwQj','bpPqPengYi','',NULL),(14,147,'Online','Online','2023-08-07 00:00:00',NULL,'2:09:PM','3:09:PM','Hi testing',0,0,3,'2023-08-07 08:39:33','ANNioB','J3BoZxjOAh','',NULL),(15,199,'Online','Online','2023-08-07 00:00:00',NULL,'3:59:PM','4:59:PM','uwirebfewhjkbfsdlhjkfsdlhjkfsdjkbh',0,0,3,'2023-08-07 10:30:04','CPNkAR','zy7qZBe9h8','',NULL),(16,279,'Online','Online','2023-08-04 00:00:00',NULL,'5:38:PM','6:38:PM','Dear Applicant,',0,0,3,'2023-08-07 12:18:51','xm6mjY','qVcyKVl3Gb','',NULL),(17,128,'Online','Online','2023-08-12 00:00:00',NULL,'6:01:PM','6:01:PM','Dear Applicant,',0,0,198,'2023-08-07 12:31:51','G8patT','Lh76omrWGM','',NULL),(18,56,'Online','Online','2023-08-03 00:00:00',NULL,'6:30:PM','7:30:PM','Dear Applicant',0,0,198,'2023-08-07 13:01:27','oBFQlN','JQlO75uX1Q','',NULL),(19,199,'Online','Online','2023-08-08 00:00:00',NULL,'10:20:PM','10:20:PM','Hi testing',0,0,3,'2023-08-07 16:51:16','B0BTQh','BvfoiawZFh','',NULL),(20,199,'Online','Online','2023-08-08 00:00:00',NULL,'10:21:PM','11:21:PM','sdsdssda',0,0,3,'2023-08-07 16:54:09','Dt5v37','kW6o2mCKNA','',NULL),(21,75,'Online','Online','2023-08-08 00:00:00',NULL,'10:36:PM','11:36:PM','sdasdsad',0,0,3,'2023-08-07 17:09:36','tV2lMs','tl1g9xvLMK','',NULL),(22,0,'Initiate Meeting','1','2023-08-17 00:00:00',NULL,'3:20:PM','3:20:PM','Template Send',0,0,197,'2023-08-17 09:59:48','TJ2BT9','WEVfCXkkqJ','1',NULL),(23,0,'Initiate Meeting','1','2023-07-04 00:00:00',NULL,'10:00:AM','11:00:AM','<p>Dear Recipient,</p>\n\n<p>Greetings for the day and I hope this email finds you well.</p>\n\n<p>I would like to invite you for a Video Conference Meeting on <strong>2023-07-04</strong> at <strong>12:000 AM</strong> for having a discussion regarding Empanelment of Arbitrators with the India International Arbitration Centre.</p>\n\n<p>To join the VC Meeting, please click on the <a href=\"https://odrphase1.techdomeaks.com/access_meeting\">Link</a>.</p>\n\n<p>Warm regards,</p>\n\n<p>Mr. Sanil Nayak</p>',0,0,296,'2023-10-06 08:41:25','3SV5O8','ZEF6BUAR9E','203,296','coa@yopmail.com'),(24,0,'Initiate Meeting','1','2023-10-10 00:00:00',NULL,'10:10:PM','11:00:PM','<p>Dear Recipient,</p>\n\n<p>Greetings for the day and I hope this email finds you well.</p>\n\n<p>I would like to invite you for a Video Conference Meeting on <strong>2023-10-10</strong> at <strong>10:10 PM</strong> for having a discussion regarding Empanelment of Arbitrators with the India International Arbitration Centre.</p>\n\n<p>To join the VC Meeting, please click on the <a href=\"https://odrphase1.techdomeaks.com/access_meeting\">Link</a>.</p>\n\n<p>Warm regards,</p>\n\n<p>Dr. Shubham Patel</p>',0,0,298,'2023-10-09 09:43:20','XXQCCD','J3O66Z4RA0','10,9,281,1,12,296,298,298','admin2@yopmail.com,admin@sislinfotech.com,aayush@yopmail.com,ashvani434@gmail.coma,admin@yopmail.com,sanilnayak@yopmail.com,shubham.patel@techdome.net.in');
/*!40000 ALTER TABLE `arbitrators_meeting` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:21:24
