-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cname` varchar(200) NOT NULL,
  `corganisation` varchar(200) NOT NULL,
  `cemail` varchar(200) NOT NULL,
  `cnumber` bigint DEFAULT NULL,
  `vnumber` varchar(15) NOT NULL,
  `created_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (100,'Dharmveer Kaushik','','',0,'HY17ACK89','2023-04-23'),(101,'Sandeep','Sislinfotech','',0,'HR 43C3233','2023-04-23'),(102,'Sandeep','','',0,'HR43C3233','2023-04-23'),(103,'Rajdeep Choudhury','','rajdeepchoudhury@gmail.com',2147483647,'DL9CAV6253','2023-04-23'),(104,'Sameer Jain','PSL','sameer@pslchambers.com',2147483647,'UP16CN8550','2023-04-23'),(105,'Divyakant Lahoti','Lahoti Advocates ','divyakant@lahotiadvocates.com',2147483647,'UP16 BU 2525','2023-04-24'),(106,'Abhishek Gupta','Advocate','abhishek_1509@hotmail.com',2147483647,'DL3CCT6687','2023-04-24'),(107,'Srimant Jain','Alvarez and Marsal','Srimant.jain@alvarezandmarsal.com',2147483647,'UP16CP7923','2023-04-24'),(108,'Vivek Gupta','SISL','vivek_gupta@sislinfotech.com',8393013494,'DL 1CAG 4035','2023-04-24'),(109,'Sandeep','SISLINFOTECH','sandeep@gmail.com',8295019701,'DL23C4423','2023-04-24'),(110,'Just Shiva Kirti Singh (retired)','Supreme Court of India ','shivakirtisingh@gmail.com',9899016327,'DL7CU2569','2023-04-27'),(111,'Vishal Aggarwal ','','vishalaggarwal.advocate@gmail.com',9814690605,'PB05-0005','2023-04-28');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:20:48
