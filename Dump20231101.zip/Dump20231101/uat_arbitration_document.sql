-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `tooltip` varchar(255) DEFAULT NULL,
  `sort` tinyint DEFAULT NULL,
  `form_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (1,'CV/ Portfolio',NULL,1,NULL,1,'cv'),(2,'Certificate of Enrolment/Registration with the relevant Institute',NULL,1,'In case the applicant is a professlonal, certificate of enrolment with the relevant isntitute(for example, Bar Council of India,Institue of Chartered Accountants of india, etc)',2,'certificate_enrolment'),(3,'Highest Educational Qualification Document','',1,'',3,'educational_qual'),(4,'Vigilance Clearance Certificate from the concerned department','only applicable for retired government employee',1,'',4,'vigilance_clearance'),(5,'List of cases conducted','as an Arbitrator/member of Arbitral Tribunal',1,NULL,5,'cases_conducted'),(6,'List of Arbitration matters','appeared before Arbitral Tribunal',1,'List of arbitration matters where applicant has appeared before arbitral tribunals ',7,'arbitration_matters'),(7,'List of Arbitration-related matters','conducted by you before Courts',1,'List of arbitration-related matters conducted by the applicant before Courts',8,'matters_before_court'),(8,'Details of academic achievements, publications, articles/writings','in the area of Arbitration',1,'Details of academic achievements, publications, articles etc. relating to arbitration',9,'achievements'),(9,'Income tax returns for preceding two years','for applicants from categories other than Service & Former Judge',1,NULL,6,'academic_income'),(10,'Year-wise number of arbitral awards published by you','as an Arbitrator/member of an Arbitral Tribunal',1,'',13,'academic_arbitral'),(11,'Copies of judgments pronounced by Courts in Arbitration matters conducted by you','in the area of Arbitration',1,NULL,10,'academic_judgments'),(12,'Statement document for no Criminal/Departmental precedings against you',NULL,1,NULL,11,'departmental_precedings'),(13,'Document relevant to experience in field of Expertise/Conduct of Arbitrational proceedings','within the last 5 years, as a sole arbitrator or as a member of any Arbitral Tribunal',1,NULL,12,'field_expertise'),(14,'Other info details','Other info details',1,'Other info details',13,'offline_entry');
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:19:31
