-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `coa_status_update`
--

DROP TABLE IF EXISTS `coa_status_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coa_status_update` (
  `id` int NOT NULL AUTO_INCREMENT,
  `arbitrators_id` int NOT NULL,
  `approved_by` int NOT NULL,
  `status` int NOT NULL,
  `previous_status` int DEFAULT NULL,
  `remark` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `send_to` bigint DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coa_status_update`
--

LOCK TABLES `coa_status_update` WRITE;
/*!40000 ALTER TABLE `coa_status_update` DISABLE KEYS */;
INSERT INTO `coa_status_update` VALUES (1,79,3,16,NULL,'hi I\'m testing for clarification',NULL,'2023-08-01 11:20:18','2023-08-01 11:20:07'),(2,105,3,14,NULL,'hi',NULL,'2023-08-01 11:57:54','2023-08-01 11:57:54'),(3,113,3,15,NULL,'jvhjvjvv',NULL,'2023-08-01 11:59:59','2023-08-01 11:59:59'),(4,286,3,14,NULL,'Approved',NULL,'2023-08-01 15:37:24','2023-08-01 15:37:24'),(5,284,3,15,NULL,'you\'re overQualified',NULL,'2023-08-07 14:21:04','2023-08-07 13:49:20'),(6,279,3,16,NULL,'Please give clarification',NULL,'2023-08-07 17:55:59','2023-08-07 17:55:59'),(7,128,198,14,NULL,'approved',NULL,'2023-08-07 18:03:03','2023-08-07 18:02:26'),(8,56,198,15,NULL,'Not approved',NULL,'2023-08-07 18:33:45','2023-08-07 18:33:07'),(9,75,3,14,NULL,'comment check',NULL,'2023-08-07 23:07:56','2023-08-07 23:07:56'),(10,199,3,16,NULL,'<p>Dear Sir/ma&#39;am,</p>\n\n<p><strong>Registrar,</strong></p>\n\n<p>India International Arbitration Centre (IIAC)</p>\n\n<p>This is in reference to the application of <strong>Justice Chiranjeev kapoor, Former Judge </strong>, seeking empanelment as an Arbitrator with the India International Arbitration Centre (IIAC).</p>\n\n<p>While considering the application, there is certain clarification/assistance required with respect to <strong> Remarks </strong>.</p>\n\n<p>You are requested to please get the same clarified from the applicant or render your kind assistance, so as to enable the process for scrutiny and consideration of the application.</p>\n\n<p>Regards,</p>\n\n<p>Dr. Vivek1 Kumar Domestic</p>\n\n<p>Member, Chamber of Arbitration, IIAC</p>',NULL,'2023-08-23 14:13:58','2023-08-23 14:13:58'),(11,199,201,15,NULL,'<p>Dear Sir/ma&#39;am,</p>\n\n<p><strong>Registrar,</strong></p>\n\n<p>India International Arbitration Centre (IIAC)</p>\n\n<p>This is to inform you that the application of <strong>Justice Chiranjeev kapoor, Former Judge </strong>, seeking empanelment as an Arbitrator with the India International Arbitration Centre (IIAC) is not approved</p>\n\n<p>You are requested to communicate my decision on the application to <strong>Justice Chiranjeev kapoor, Former Judge </strong>, after obtaining the decision of the remaining Members of the Chamber of Arbitration.</p>\n\n<p>Regards,</p>\n\n<p>Mr. Vivek Kumar Domestic</p>\n\n<p>Member, Chamber of Arbitration, IIAC</p>',NULL,'2023-08-23 14:28:46','2023-08-23 14:28:46');
/*!40000 ALTER TABLE `coa_status_update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:17:37
