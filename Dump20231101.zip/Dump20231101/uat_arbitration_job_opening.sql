-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `job_opening`
--

DROP TABLE IF EXISTS `job_opening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_opening` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `last_date` date NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_opening`
--

LOCK TABLES `job_opening` WRITE;
/*!40000 ALTER TABLE `job_opening` DISABLE KEYS */;
INSERT INTO `job_opening` VALUES (8,'Recruitment Notification No.  A-12011/6/2023-Administration(AR)-IIAC for various post','2023-09-23','admin/homepage_docs/job_opening/1698647563Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-09-21 13:40:34','2023-10-30 12:02:43'),(9,'Recruitment Notification For Various Posts On Contractual Basis  At India International Arbitration Centre (IIAC)','2023-09-22','admin/homepage_docs/job_opening/1695284073India_International_Arbitration_Centre.pdf',1,'2023-09-21 13:44:33','2023-10-01 14:23:31'),(10,'Recruitment Notification For Various Posts On Contractual Basis At India International Arbitration Centre (IIAC) new','2023-10-28','admin/homepage_docs/job_opening/1696500605techdome_solutions_-_black_(1).png',0,'2023-10-05 15:40:05','2023-10-05 15:40:35'),(11,'techdome ','2023-03-01',NULL,1,'2023-10-09 15:28:54','2023-10-09 15:28:54'),(12,'Techdome ','2023-12-01',NULL,0,'2023-10-09 15:31:52','2023-10-27 21:14:20'),(13,'Sidhi Bharti','2222-02-22','admin/homepage_docs/job_opening/1698419296Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-09 15:33:24','2023-10-30 12:00:25'),(14,'Sample Job','2222-02-22',NULL,1,'2023-10-27 20:49:16','2023-10-30 12:01:00'),(15,'Vigyapan','2024-01-01','admin/homepage_docs/job_opening/1698420343recruitmentadvtforconstablecadre.pdf',1,'2023-10-27 20:55:43','2023-10-27 20:55:43'),(16,'Vigyapan 1','2023-11-04','admin/homepage_docs/job_opening/1698420446Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-27 20:57:26','2023-10-27 20:57:26'),(17,'Sidhi Bharti 1','2023-12-15','admin/homepage_docs/job_opening/1698421199recruitmentadvtforconstablecadre.pdf',1,'2023-10-27 21:09:59','2023-10-27 21:09:59'),(18,'Testing Jobs','2023-11-05','admin/homepage_docs/job_opening/1698421235Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-27 21:10:35','2023-10-27 21:10:35'),(19,'Sample Job Posting for recruitment Of QA lead','2023-11-22',NULL,1,'2023-10-30 12:03:50','2023-10-30 12:03:50'),(20,'Jobs Testing','2024-01-03',NULL,1,'2023-10-30 12:11:56','2023-10-30 12:11:56');
/*!40000 ALTER TABLE `job_opening` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:19:49
