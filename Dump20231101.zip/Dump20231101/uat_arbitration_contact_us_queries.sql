-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contact_us_queries`
--

DROP TABLE IF EXISTS `contact_us_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_us_queries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `query_related_to` varchar(100) NOT NULL,
  `message` varchar(500) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `created_time` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_us_queries`
--

LOCK TABLES `contact_us_queries` WRITE;
/*!40000 ALTER TABLE `contact_us_queries` DISABLE KEYS */;
INSERT INTO `contact_us_queries` VALUES (1,'MONOJ SEN','monojsen@gmail.com','P','Dear Sir/Madam, <br><br> User <b>MONOJ SEN</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: 1) whats the last date for application ?\n2} application fee and mode of payment\n  <br><br> User: MONOJ SEN <br> Email: monojsen@gmail.com<br><br> Regards, <br> Team IIAC','1.38.52.3','2023-05-26','20:06:28'),(2,'venkata krishna rao kolluru','raokvk@yahoo.com','P','Dear Sir/Madam, <br><br> User <b>venkata krishna rao kolluru</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: Typo in email ID given for sending Empanelment Fee Details \n\n  registrar@indiaiac.org <br><br> User: venkata krishna rao kolluru <br> Email: raokvk@yahoo.com<br><br> Regards, <br> Team IIAC','163.116.219.33','2023-05-27','22:29:58'),(3,'Ishan kapoor','kapoorishan09@gmail.com','P','Dear Sir/Madam, <br><br> User <b>Ishan kapoor</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: What is the process ? The notification states that one needs to apply at iiac website but there is no tab for the same.  <br><br> User: Ishan kapoor <br> Email: kapoorishan09@gmail.com<br><br> Regards, <br> Team IIAC','49.36.191.189','2023-05-29','11:38:45'),(4,'Ganesh Chandra Kabi','gckabi@gmail.com','P','Dear Sir/Madam, <br><br> User <b>Ganesh Chandra Kabi</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: Application ID: 24\nI have submitted my application but unable to make the payment. Kindly share the link for online payment or details for making offline payment <br><br> User: Ganesh Chandra Kabi <br> Email: gckabi@gmail.com<br><br> Regards, <br> Team IIAC','182.69.178.159','2023-05-29','12:32:55'),(5,'Vaishali','vaishali.nautiyal@induslaw.com','P','Dear Sir/Madam, <br><br> User <b>Vaishali</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I am part of branding team of IndusLaw. We would like to be registered as arbitrator. Kindly suggest on the process. <br><br> User: Vaishali <br> Email: vaishali.nautiyal@induslaw.com<br><br> Regards, <br> Team IIAC','103.235.2.60','2023-05-29','14:14:49'),(6,'Danish Khan','danishkhaan5384@gmail.com','L','Dear Sir/Madam, <br><br> User <b>Danish Khan</b> has raised the query on website. Query related to: <b> Legal Counsellor </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I am final year law at Jamia Millia islamia and wish to apply for an internship with you for the month of July, 2023. How shall I proceed with the same? <br><br> User: Danish Khan <br> Email: danishkhaan5384@gmail.com<br><br> Regards, <br> Team IIAC','42.108.7.217','2023-06-02','13:54:41'),(7,'Rajeev Ranjan','Rajeev@rkschambers.com','P','Dear Sir/Madam, <br><br> User <b>Rajeev Ranjan</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: Unable to insert enrolment number while filling empanelment form. <br><br> User: Rajeev Ranjan <br> Email: Rajeev@rkschambers.com<br><br> Regards, <br> Team IIAC','122.179.200.70','2023-06-03','11:58:42'),(8,'RAJESH KUMAR MITTAL','csrajeshmittal@gmail.com','P','Dear Sir/Madam, <br><br> User <b>RAJESH KUMAR MITTAL</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: Whats the fees for empanelment as domestic and both <br><br> User: RAJESH KUMAR MITTAL <br> Email: csrajeshmittal@gmail.com<br><br> Regards, <br> Team IIAC','43.241.126.51','2023-06-06','13:23:48'),(9,'Mishra Pushpa Kumari','pushpamishra200@gmail.com','P','Dear Sir/Madam, <br><br> User <b>Mishra Pushpa Kumari  </b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: Online registration no.. <br><br> User: Mishra Pushpa Kumari   <br> Email: pushpamishra200@gmail.com<br><br> Regards, <br> Team IIAC','122.176.203.43','2023-06-07','12:45:19'),(10,'v s rao','vsrao98@gmail.com','P','Dear Sir/Madam, <br><br> User <b>v s rao</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I sent mail on 07-06-2023 to Registrar regarding  payment of application. <br><br> User: v s rao <br> Email: vsrao98@gmail.com<br><br> Regards, <br> Team IIAC','117.198.151.163','2023-06-08','10:09:19'),(11,'jerry raju','jerry1330raju@gmail.com','L','Dear Sir/Madam, <br><br> User <b>jerry raju</b> has raised the query on website. Query related to: <b> Legal Counsellor </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I would like to apply for an internship at India International arbitration centre. Currently i am pursuing LLB from Delhi university in 1st yr. How can i apply so? <br><br> User: jerry raju <br> Email: jerry1330raju@gmail.com<br><br> Regards, <br> Team IIAC','122.162.147.160','2023-06-12','15:22:23'),(12,'Aanya Saluja','aanya@kaplegal.com','P','Dear Sir/Madam, <br><br> User <b>Aanya Saluja </b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: We have submitted the Application on behalf of Mr. Sumeet Kachwaha and wanted to confirm if it is on record.  <br><br> User: Aanya Saluja  <br> Email: aanya@kaplegal.com<br><br> Regards, <br> Team IIAC','106.215.86.177','2023-06-12','16:32:11'),(13,'Dikshant','dikshantdagar02@gmail.com','A','Dear Sir/Madam, <br><br> User <b>Dikshant</b> has raised the query on website. Query related to: <b> Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: aaaa <br><br> User: Dikshant <br> Email: dikshantdagar02@gmail.com<br><br> Regards, <br> Team IIAC','202.54.205.162','2023-06-14','12:43:00'),(14,'Justice Alok Verma','alokver55@gmail.com','P','Dear Sir/Madam, <br><br> User <b>Justice Alok Verma </b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I have applied for empanelment as Arbitrator but have not received any confirmation  <br><br> User: Justice Alok Verma  <br> Email: alokver55@gmail.com<br><br> Regards, <br> Team IIAC','223.181.138.91','2023-06-14','18:31:01'),(15,'Rajendra Jha','vedantaceo@gmail.com','P','Dear Sir/Madam, <br><br> User <b>Rajendra Jha</b> has raised the query on website. Query related to: <b> Panel of Arbitration </b> <br> Kindly review the query and acknowledge the requester on the same mail ID. <br><br>  Query: I have applied online for empanelment as an Arbitrator <br><br> User: Rajendra Jha <br> Email: vedantaceo@gmail.com<br><br> Regards, <br> Team IIAC','152.58.93.197','2023-06-15','10:01:04');
/*!40000 ALTER TABLE `contact_us_queries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:27:15
