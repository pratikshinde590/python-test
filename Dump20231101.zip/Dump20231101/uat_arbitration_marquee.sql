-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `marquee`
--

DROP TABLE IF EXISTS `marquee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marquee` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `document_type` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `document_name` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `document_url` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marquee`
--

LOCK TABLES `marquee` WRITE;
/*!40000 ALTER TABLE `marquee` DISABLE KEYS */;
INSERT INTO `marquee` VALUES (1,'Revised Notice Regarding Empanelment of Arbitrators at India International Arbitration Centre (IIAC)','application/pdf','1695115527revised_notice_2806231510.pdf','admin/homepage_docs/marquee/1695115527revised_notice_2806231510.pdf',1,'2023-09-19 14:55:27','2023-09-19 14:59:21'),(2,'Results Announced: For Various Posts At India International Arbitration Centre (IIAC)','application/pdf','1695115552India_International_Arbitration_Centre.pdf','admin/homepage_docs/marquee/1695115552India_International_Arbitration_Centre.pdf',1,'2023-09-19 14:55:52','2023-10-05 13:30:54'),(3,'Test by Shailendra','application/pdf','1696307633march_2023_nlad_and_acp_api.pdf','admin/homepage_docs/marquee/1696307633march_2023_nlad_and_acp_api.pdf',0,'2023-10-03 10:03:53','2023-10-27 23:53:49'),(5,'This is marquee item intended for testing purpose only','application/pdf','1698431007Shidhi_Bharti_2023_Vyapam.pdf','admin/homepage_docs/marquee/1698431007Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-27 23:53:27','2023-10-27 23:55:11');
/*!40000 ALTER TABLE `marquee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:20:58
