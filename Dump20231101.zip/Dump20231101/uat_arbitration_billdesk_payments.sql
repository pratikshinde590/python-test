-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `billdesk_payments`
--

DROP TABLE IF EXISTS `billdesk_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billdesk_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `mercid` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transaction_date` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `surcharge` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_method_type` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `amount` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `ru` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `orderid` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transaction_error_type` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `discount` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_category` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `bank_ref_no` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transactionid` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `txn_process_type` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `bankid` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `itemcode` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transaction_error_code` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `currency` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `auth_status` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `transaction_error_desc` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `objectid` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `charge_amount` varchar(25) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billdesk_payments`
--

LOCK TABLES `billdesk_payments` WRITE;
/*!40000 ALTER TABLE `billdesk_payments` DISABLE KEYS */;
INSERT INTO `billdesk_payments` VALUES (1,'UATIIACV2','2023-10-30T13:53:53+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER960298','success','0.00','02','BILLDESK12','USBI0000718250','nb','SBI','DIRECT','TRS0000','356','0300','Transaction Successful','transaction','300.00','2023-10-30 14:22:03','2023-10-30 14:22:03'),(2,'UATIIACV2','2023-10-30T14:37:35+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER435505','payment_processing_error','0.00','02','BILLDESK12','USBI0000718259','nb','SBI','DIRECT','TRPPE0033','356','0399','Payment processing error','transaction','300.00','2023-10-30 14:37:58','2023-10-30 14:37:58'),(3,'UATIIACV2','2023-10-30T14:44:02+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER200625','success','0.00','02','BILLDESK12','USBI0000718264','nb','SBI','DIRECT','TRS0000','356','0300','Transaction Successful','transaction','300.00','2023-10-30 14:44:11','2023-10-30 14:44:11'),(4,'UATIIACV2','2023-10-30T17:19:19+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER705550','success','0.00','02','BILLDESK12','USBI0000718371','nb','SBI','DIRECT','TRS0000','356','0300','Transaction Successful','transaction','300.00','2023-10-30 17:19:29','2023-10-30 17:19:29'),(5,'UATIIACV2','2023-10-30T17:32:37+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER868553','success','0.00','02','BILLDESK12','USBI0000718377','nb','SBI','DIRECT','TRS0000','356','0300','Transaction Successful','transaction','300.00','2023-10-30 17:33:10','2023-10-30 17:33:10'),(6,'UATIIACV2','2023-10-30T17:42:57+05:30','0.00','netbanking','300.00','http://127.0.0.1:8000/odr/test-payment/pgresponse/redirect','ORDER467232','success','0.00','02','BILLDESK12','USBI0000718379','nb','SBI','DIRECT','TRS0000','356','0300','Transaction Successful','transaction','300.00','2023-10-30 17:43:06','2023-10-30 17:43:06');
/*!40000 ALTER TABLE `billdesk_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:21:33
