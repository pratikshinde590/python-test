-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gallery`
--

DROP TABLE IF EXISTS `gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gallery` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `place` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery`
--

LOCK TABLES `gallery` WRITE;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT INTO `gallery` VALUES (1,'Arbitration & Dispute Resolution: Creating Conducive Business Climate','','2023-04-30','New Delhi',1,'2023-09-19 11:03:37','2023-09-19 11:03:37'),(2,'Delhi Discourse 2023 organized by Federation of Indian Corporate Lawyers','Hon’ble Mr. Justice Hemant Gupta (Retd.), Chairperson, India International Arbitration Centre (IIAC) was invited to Conference titled “Delhi Discourse 2023” with the theme “Navigating India\'s Legal Terrain in the Era of Amrit Kaal” , organised by Federati','2023-05-16','New Delhi',1,'2023-09-19 11:29:03','2023-09-19 11:29:03'),(3,'India International Arbitration Centre (IIAC) organized “Indian Arbitration Leadership Roundtable”','India International Arbitration Centre (IIAC) organized “Indian Arbitration Leadership Roundtable” with practitioners from leading law firms','2023-05-27','New Delhi',1,'2023-09-19 11:35:26','2023-09-19 11:35:26'),(4,'India Dispute Resolution Forum 7th and 8th June, St. James Court, Taj Hotel , London','Hon’ble Mr. Justice Hemant Gupta (Retd.), Chairperson, IIAC was invited as Speaker and Moderator at India Dispute Resolution Forum 2023, organised by ThoughtLeaders4Disputes on 8th June 2023 at St. James Court , Taj Hotel, London, to share his views on th','2023-06-08','London',1,'2023-09-19 11:40:27','2023-09-19 11:40:27'),(5,'Conference on Arbitrating INDO-UK Commercial Disputes - 2ND EDITION','','2023-06-05','London',1,'2023-09-19 11:46:24','2023-09-19 11:46:24'),(7,'Conference on Arbitrating INDO-UK Commercial Disputes - 2ND EDITION new','Test','2023-10-28','Indore',1,'2023-10-05 15:48:51','2023-10-05 15:48:51'),(8,'Confrenece','Conference on XYZ Topic and its effects in International law ','2023-10-07','indore',1,'2023-10-09 16:58:15','2023-10-09 16:58:15'),(9,'Contractual Dispute Resolution Workshop','Join us for an engaging half-day workshop focused on Contractual Dispute Resolution strategies and best practices. Designed for legal professionals, in-house counsel, and contract managers, this workshop aims to enhance your proficiency in navigating and ','2023-10-30','Nagpur, India',1,'2023-10-12 20:32:16','2023-10-12 20:32:16'),(10,'Test edited by shri','Tes','2023-10-26','Nagpur, India',1,'2023-10-17 00:29:25','2023-10-17 00:29:25'),(11,'Test by shri','ad','2023-10-18','sfsf',1,'2023-10-17 00:30:31','2023-10-17 00:30:31'),(12,'Test Gallery','Test Gallery','2023-10-05','New Delhi',1,'2023-10-25 18:24:49','2023-10-25 18:24:49'),(13,'Test 26th Oct','Test','2023-10-24','Nagpur, India',0,'2023-10-26 22:54:28','2023-10-27 15:29:40'),(14,'Event Photo','This is test Image','2023-10-30','Raipur',0,'2023-10-27 18:32:44','2023-10-27 18:51:27'),(15,'Test123','This is test Image','2023-10-13','Delhi',0,'2023-10-27 18:42:16','2023-10-30 12:37:07'),(16,'Event Images','Event held at IIAC Testing','2023-10-06','IIAC campus',0,'2023-10-30 11:36:05','2023-10-30 11:58:15'),(17,'tech dome ','techdome ','2023-10-30','indore ',0,'2023-10-30 13:18:34','2023-10-30 13:19:46'),(18,'XYZ Testing','This is testing gallery','2023-10-11','Bhopal',1,'2023-11-01 14:46:20','2023-11-01 14:46:20');
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:19:57
