-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transformed_data`
--

DROP TABLE IF EXISTS `transformed_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transformed_data` (
  `my_row_id` bigint unsigned NOT NULL AUTO_INCREMENT /*!80023 INVISIBLE */,
  `applicationId` int DEFAULT NULL,
  `Transaction_Type1` varchar(255) DEFAULT NULL,
  `subscriberId` varchar(255) DEFAULT NULL,
  `Update_Indicator_1` varchar(255) DEFAULT NULL,
  `Phone_Number_in_EBBP` varchar(255) DEFAULT NULL,
  `First_Name` varchar(255) DEFAULT NULL,
  `Last_Name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `Date_of_Birth` date DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `primary_address1` varchar(255) DEFAULT NULL,
  `primaryCity` varchar(255) DEFAULT NULL,
  `primaryState` varchar(255) DEFAULT NULL,
  `Primary_Zip_Code` varchar(255) DEFAULT NULL,
  `Primary_Urbanization_Code` varchar(255) DEFAULT NULL,
  `mailingAddress` varchar(255) DEFAULT NULL,
  `mailingAddress2` varchar(255) DEFAULT NULL,
  `mailingCity` varchar(255) DEFAULT NULL,
  `mailingState` varchar(255) DEFAULT NULL,
  `Mailing_Zip_Code` varchar(255) DEFAULT NULL,
  `mailingUrbanizationCode` varchar(255) DEFAULT NULL,
  `serviceType` varchar(255) DEFAULT NULL,
  `serviceInitialization_Date` date DEFAULT NULL,
  `bqp_last_name` varchar(255) DEFAULT NULL,
  `bqp_first_name` varchar(255) DEFAULT NULL,
  `bqp_middle_name` varchar(255) DEFAULT NULL,
  `bqp_date_of_birth` date DEFAULT NULL,
  `bqp_last_4_ssn` varchar(255) DEFAULT NULL,
  `bqp_tribal_id` varchar(255) DEFAULT NULL,
  `ebbp_tribal_benefit_flag` varchar(255) DEFAULT NULL,
  `device_copay` varchar(255) DEFAULT NULL,
  `etc_general_use` varchar(255) DEFAULT NULL,
  `device_reimbursement_date` date DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `device_make` varchar(255) DEFAULT NULL,
  `consumer_fee` varchar(255) DEFAULT NULL,
  `device_model` varchar(255) DEFAULT NULL,
  `model_number` varchar(255) DEFAULT NULL,
  `device_delivery_method` varchar(255) DEFAULT NULL,
  `market_value` varchar(255) DEFAULT NULL,
  `expected_rate_device` varchar(255) DEFAULT NULL,
  `avp_program_exception` varchar(255) DEFAULT NULL,
  `Eligibility_Code` varchar(255) DEFAULT NULL,
  `school_lunch_exception` varchar(255) DEFAULT NULL,
  `school_lunch_cert` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `consumer_email` varchar(255) DEFAULT NULL,
  `contact_phone_number` varchar(255) DEFAULT NULL,
  `ams_failure_exception` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dup_address_exception` varchar(255) DEFAULT NULL,
  `expected_rate` varchar(255) DEFAULT NULL,
  `include_subscriber_id` varchar(255) DEFAULT NULL,
  `rep_id` varchar(255) DEFAULT NULL,
  `rep_not_assisted` varchar(255) DEFAULT NULL,
  `acp_cert_ind` varchar(255) DEFAULT NULL,
  `consents` varchar(255) DEFAULT NULL,
  `tab_group` varchar(255) DEFAULT NULL,
  `transfer_exception` varchar(255) DEFAULT NULL,
  `tribalId` varchar(255) DEFAULT NULL,
  `transactionEffectiveDate` date DEFAULT NULL,
  `SAC_Code` varchar(255) DEFAULT NULL,
  `Last_4ssn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`my_row_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transformed_data`
--

LOCK TABLES `transformed_data` WRITE;
/*!40000 ALTER TABLE `transformed_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `transformed_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:22:46
