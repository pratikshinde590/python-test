-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `offline_payment`
--

DROP TABLE IF EXISTS `offline_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offline_payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `utr_no` varchar(30) DEFAULT NULL,
  `payment_receipt` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_mode` int NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_payment`
--

LOCK TABLES `offline_payment` WRITE;
/*!40000 ALTER TABLE `offline_payment` DISABLE KEYS */;
INSERT INTO `offline_payment` VALUES (1,1,'123456789QWERTY1234567','/tmp/phpKldE9y','payment_receipt/1684999602International_Arbitration_portal.pdf','2023-05-25',0,'2023-05-25 07:26:43',1,'2023-05-25 07:26:43'),(2,3,'1234567890123456789012','/tmp/phpkSCMqL','payment_receipt/1685008857minister-madam.png','1970-01-01',0,'2023-05-25 10:00:57',1,'2023-05-25 10:00:57'),(3,2,'2133424344542323222323','/tmp/phpnSoCJK','payment_receipt/16850123828900a3db-1e92-48f6-8fc0-1697a0abf970.docx','2023-05-25',0,'2023-05-25 10:59:42',1,'2023-05-25 10:59:42'),(4,11,'12345678901234567890ab','/tmp/phpKqhIcy','payment_receipt/1685012482img1_0.jpg','2023-05-25',0,'2023-05-25 11:01:22',1,'2023-05-25 11:01:22'),(5,12,'452345353245235235','/tmp/php90IuS8','payment_receipt/1685023643Sample.pdf','2023-05-09',0,'2023-05-25 14:07:23',1,'2023-05-25 14:07:23'),(6,23,'PUNBH23146890355','/tmp/phpDoiOd8','payment_receipt/1685097671fee.pdf','2023-05-26',0,'2023-05-26 10:41:11',1,'2023-05-26 10:41:11'),(7,30,'314620659865/XXXXXXX39','/tmp/phpTbnT45','payment_receipt/1685129982Fee_Payment_KVKRao.jpg','2023-05-27',0,'2023-05-26 19:39:42',1,'2023-05-26 19:39:42'),(8,21,'IMPS000230215933','/tmp/phpGj74ZK','payment_receipt/1685158558IMPS_Transaction_Receipt.pdf','2023-05-26',0,'2023-05-27 03:35:58',1,'2023-05-27 03:35:58'),(9,15,'04518282529262262','/tmp/phpIrR4DD','payment_receipt/1685199171pete-walls-FGG3s99wQrU-unsplash.jpg','2023-05-11',0,'2023-05-27 14:52:51',1,'2023-05-27 14:52:51'),(10,33,'0000314820288720','/tmp/phpvaDWuu','payment_receipt/1685288401PAYMENT_RECEIPT.jpg','2023-05-28',0,'2023-05-28 15:40:01',1,'2023-05-28 15:40:01'),(11,39,'N149232476019495','/tmp/phpVHOG9h','payment_receipt/1685321389Empanelment_Fee.pdf','2023-05-29',0,'2023-05-29 00:49:49',1,'2023-05-29 00:49:49'),(12,58,'N150232479073384','/tmp/phpibaMsW','payment_receipt/1685455192Transfer_to_India_International_Arbitration_Centre_5618_30-05-23_19.26.pdf','2023-05-30',0,'2023-05-30 13:59:52',1,'2023-05-30 13:59:52'),(13,95,'SBIN523153671584','/tmp/phpu0TOmL','payment_receipt/1685703618IIAC_RECIEPT.pdf','2023-06-02',0,'2023-06-02 11:00:18',1,'2023-06-02 11:00:18'),(14,96,'UPI 315385316757','/tmp/phplcFmUD','payment_receipt/1685706355IIAC_Payment_Proof.jpg','2023-06-02',0,'2023-06-02 11:45:56',1,'2023-06-02 11:45:56'),(15,113,'315417928998cnrb','/tmp/php2llOJc','payment_receipt/1685792526payment_.pdf','2023-06-03',0,'2023-06-03 11:42:06',1,'2023-06-03 11:42:06'),(16,119,'ICICI315521314254','/tmp/phpaPsCrX','payment_receipt/1685894546InitiateSingleEntryPaymentSummary04-06-2023.pdf','2023-06-04',0,'2023-06-04 16:02:26',1,'2023-06-04 16:02:26'),(17,126,'N283672375674251365','/tmp/phpb5wmDi','payment_receipt/1685966528file-example_PDF_500_kB.pdf','2023-06-05',0,'2023-06-05 12:02:08',1,'2023-06-05 12:02:08'),(18,111,'SBIN223156968988','/tmp/phpTBttVT','payment_receipt/1685967010Receipt_10000.pdf','2023-06-05',0,'2023-06-05 12:10:10',1,'2023-06-05 12:10:10'),(19,59,'2306051916372324693946','/tmp/phpO4F5At','payment_receipt/1685973142WhatsApp_Image_2023-06-05_at_7.20.47_PM.jpeg','2023-06-05',0,'2023-06-05 13:52:22',1,'2023-06-05 13:52:22'),(20,35,'2134567834561234567','/tmp/phpmCiLTY','payment_receipt/1686118531Adobe_Scan_01-Jun-2023_(2).pdf','2023-06-06',0,'2023-06-07 06:15:31',1,'2023-06-07 06:15:31'),(21,42,'SBIN123158363907','/tmp/phpq25P1k','payment_receipt/1686133355State_Bank_of_India.pdf','2023-06-07',0,'2023-06-07 10:22:35',1,'2023-06-07 10:22:35'),(22,128,'654376568666576547','/tmp/phpbquy0d','payment_receipt/1686204762Screenshot11.png','2023-06-07',0,'2023-06-08 06:12:42',1,'2023-06-08 06:12:42'),(24,152,'N283672375674251365','/tmp/php0IRqZH','payment_receipt/1686220325file-example_PDF_500_kB.pdf','2023-06-04',0,'2023-06-08 10:32:05',1,'2023-06-08 10:32:05'),(25,47,'315915707208','/tmp/php34w0wC','payment_receipt/1686221755CamScanner_06-08-2023_16.21.pdf','2023-06-08',0,'2023-06-08 10:55:55',1,'2023-06-08 10:55:55'),(26,133,'SBIN223159504450','/tmp/phpCwSRKx','payment_receipt/1686226416Fees_of_IIAC.pdf','2023-06-08',0,'2023-06-08 12:13:36',1,'2023-06-08 12:13:36'),(27,121,'SBIN323160665833','/tmp/php8TwEDJ','payment_receipt/168629273520230609011059.pdf','2023-06-09',0,'2023-06-09 06:38:55',1,'2023-06-09 06:38:55'),(28,87,'316016646440','/tmp/phpMzq1jO','payment_receipt/168630935941D36BB8-9078-496C-B127-B559B79B1C4A.png','2023-06-09',0,'2023-06-09 11:15:59',1,'2023-06-09 11:15:59'),(29,160,'316152022995','/tmp/phpPD4WU6','payment_receipt/1686378531Payment_Reference_ID.png','2023-06-10',0,'2023-06-10 06:28:51',1,'2023-06-10 06:28:51'),(30,166,'N165232503929384','/tmp/phpQPbbUo','payment_receipt/1686739860IIAC_PAYMENT.docx','2023-06-14',0,'2023-06-14 10:51:00',1,'2023-06-14 10:51:00'),(31,176,'316714145210','/tmp/phpQLSq89','payment_receipt/1686908461Welcome_to_HDFC_Bank_NetBanking.pdf','2023-06-16',0,'2023-06-16 09:41:01',1,'2023-06-16 09:41:01'),(32,177,'SBIN523167087128','/tmp/php3tJqbK','payment_receipt/1686912099NEFT_FOR_EMPANELMENT_ARBITRATOR_JUSTICE_RAGHVENDRA_KUMAR.pdf','2023-06-16',0,'2023-06-16 10:41:39',1,'2023-06-16 10:41:39'),(33,159,'23563265263723672','/tmp/phpVEGArN','payment_receipt/1687240317file-example_PDF_500_kB.pdf','2023-06-05',0,'2023-06-20 05:51:57',1,'2023-06-20 05:51:57'),(34,195,'N283672375674251365','/tmp/phpebKaan','payment_receipt/1687342766file-example_PDF_500_kB.pdf','2023-06-05',0,'2023-06-21 10:19:26',1,'2023-06-21 10:19:26'),(35,20,'N283672375674251365','/tmp/phpMBBZiV','payment_receipt/1687779765file-example_PDF_500_kB.pdf','2023-06-05',0,'2023-06-26 11:42:45',1,'2023-06-26 11:42:45'),(36,151,'12345678901234567890','/tmp/php5HsX3w','payment_receipt/1687780586002f7f6b-552a-4baf-9b30-eb8b2edc9683.docx','2023-05-22',0,'2023-06-26 11:56:26',1,'2023-06-26 11:56:26'),(37,199,'12345678','/tmp/phpZUuVtF','payment_receipt/1687781165MicrosoftTeams-image_(2).png','2023-06-10',0,'2023-06-26 12:06:05',1,'2023-06-26 12:06:05'),(38,282,'dffdfdfdferefe','/tmp/phpMGVbE2','payment_receipt/1688197680myfile.pdf','2022-07-05',0,'2023-07-01 07:48:00',1,'2023-07-01 07:48:00'),(39,283,'sfdz5465465765467','/tmp/phpOYarON','payment_receipt/1688207554myfile-4.pdf','2023-06-05',0,'2023-07-01 10:32:34',1,'2023-07-01 10:32:34'),(40,286,'N283672375674251365','/tmp/php6Hkong','payment_receipt/1690287932file-sample_150kB.pdf','2023-07-02',0,'2023-07-25 17:55:33',1,'2023-07-25 17:55:33'),(41,284,'53454364vhvj3546','/tmp/phpW0V7QB','payment_receipt/1690872396myfile_(1).pdf','2023-08-01',0,'2023-08-01 12:16:37',1,'2023-08-01 12:16:37'),(42,294,'UTR1234','1696218884_march_2023_nlad_and_acp_api.pdf','https://odrphase1.techdomeaks.com/arbitrator_docs/payment_receipt/1696218884_march_2023_nlad_and_acp_api.pdf','2023-10-02 09:24:44',0,'2023-10-02 03:54:45',0,'2023-10-02 03:54:45'),(43,295,'UTR12345679','1696307134_march_2023_nlad_and_acp_api.pdf','http://127.0.0.1:8000/arbitrator_docs/payment_receipt/1696307134_march_2023_nlad_and_acp_api.pdf','2023-10-03 09:55:34',0,'2023-10-03 04:25:35',0,'2023-10-03 04:25:35');
/*!40000 ALTER TABLE `offline_payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:18:58
