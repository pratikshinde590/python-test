-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (13,'2014_10_12_000000_create_users_table',1),(14,'2014_10_12_100000_create_password_resets_table',1),(15,'2019_08_19_000000_create_failed_jobs_table',1),(16,'2019_12_14_000001_create_personal_access_tokens_table',1),(17,'2021_11_02_000000_create_otp_tokens_table',1),(18,'2023_02_02_112201_add_mobile_no_in_users_table',2),(19,'2023_02_08_064230_create_verification_codes_table',2),(20,'2023_02_08_092544_add_is_deleted_in_users_table',3),(21,'2023_02_08_093354_add_is_active_in_users_table',4),(22,'2023_02_09_054445_add_salutation_first_middle_last_name_in_users_table',5),(23,'2023_02_09_063647_add_gender_dob_qualification_nationalty_in_users_table',6),(24,'2023_02_09_123036_create_crud_events_table',7),(25,'2023_06_07_031700_create_seek_diputes_table',7),(26,'2023_06_08_025237_create_events_table',7),(27,'2023_06_08_030645_create_dispute_documents_table',7),(28,'2023_06_20_114358_create_dispute_payments_table',7),(29,'2023_06_29_183133_create_notifications__table',7),(30,'2023_06_29_193908_create_modules_table',8),(31,'2023_08_02_204635_create_procedural_timetables_table',7),(32,'2023_08_02_223239_create_preliminary_meetings_table',7),(33,'2023_08_24_133421_create_charges_info_table',9),(34,'2023_08_29_141009_create_preliminary_meetings_docs_table',9),(35,'2023_08_31_131203_add_time_to_preliminary_meetings_table',9),(36,'2023_09_01_190156_create_payments_table',9),(37,'2023_09_01_224704_add_meeting_status_to_preliminary_meetings_table',9),(38,'2023_09_02_232451_create_procedural_timetable_responses_table',9),(39,'2023_09_07_164636_add_category_to_acts_table',7),(40,'2023_09_18_133211_create_gallery_table',10),(41,'2023_09_18_133503_create_gallery_images_table',10),(42,'2023_09_19_130708_create_marquee_table',11),(43,'2023_09_19_164245_create_carousel_table',12),(44,'2023_09_19_225553_create_homepage_events_table',13),(45,'2023_09_19_230224_create_event_guests_table',13),(46,'2023_06_22_042503_add_columns_to_seek_diputes_table',13),(47,'2023_09_20_103256_make_last_date_nullable_in_job_opening_table',13),(48,'2023_09_20_154258_add_link_to_carousel_table',14),(49,'2023_09_12_223543_create_respondents_table',15),(50,'2023_10_12_025953_add_time_to_homepage_events_table',15),(51,'2023_10_29_165057_add_event_url_to_homepage_events',16),(52,'2023_10_30_140624_create_billdesk_payments_table',17);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:21:57
