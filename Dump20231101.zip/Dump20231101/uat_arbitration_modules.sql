-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'Sit soluta aut molestias aut.','Et excepturi modi tempora mollitia est molestiae nobis. Accusamus animi necessitatibus sed doloribus sequi nostrum ut. Ipsam et dolorem quisquam earum vitae quia. Accusamus animi quam voluptatem unde sed et ex facilis.',NULL,NULL),(2,'Molestiae sint iste facilis eius voluptatum.','Nisi aut qui autem hic doloremque ab. Laboriosam libero veritatis a consequatur non. Impedit voluptatem hic earum dolorem recusandae. Corporis autem at quasi voluptatem dicta.',NULL,NULL),(3,'Illum sunt quos eaque.','Voluptates voluptate qui modi minus eos odio. Voluptatem ut maiores tempore dolorum. Magni non sit hic et eveniet ut.',NULL,NULL),(4,'Et ea et nam eaque sit aperiam quae omnis.','Eos ab inventore earum. Incidunt animi ullam animi excepturi velit ipsum. Voluptatem repellat aut ex temporibus unde. Enim doloribus eaque molestiae eum autem.',NULL,NULL),(5,'Consequatur incidunt est facere rerum cum ut quis.','Quis odit ipsam ipsum est beatae. Id porro velit fugiat amet.',NULL,NULL),(6,'Ducimus et inventore sequi sint.','A placeat ea quasi ab saepe. Molestiae animi placeat neque voluptatem repudiandae consequatur minus. Ut voluptas perferendis eos soluta est officia.',NULL,NULL),(7,'Illo iure expedita vitae et illum delectus expedita.','Animi ea id rerum sit est sapiente. Enim aspernatur quam quasi a culpa. Nisi beatae repellendus consequatur delectus. Autem ut totam explicabo temporibus consequuntur non minus. Veritatis laborum odio non ducimus.',NULL,NULL),(8,'Est voluptatem ut eius saepe quae.','Iure mollitia quos praesentium id qui aut temporibus. Sed nihil quisquam et et. Officia est voluptate non cum repudiandae assumenda asperiores eius. Ullam perspiciatis aut aut.',NULL,NULL),(9,'Quia hic qui quod.','Exercitationem sint ex suscipit ut quod sit voluptate. Nam consequatur hic suscipit expedita et quas exercitationem. Architecto voluptatum ex et excepturi reprehenderit doloremque. Eos voluptatem sed nihil vel nihil. Debitis voluptatem quia et assumenda c',NULL,NULL),(10,'Doloremque vel quidem soluta reiciendis dicta vel.','Ipsam nam omnis in et quia. Necessitatibus fugit quo autem nemo. Magni et eaque et ea. Dignissimos nemo consequuntur facilis blanditiis error quia et autem.',NULL,NULL);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:26:34
