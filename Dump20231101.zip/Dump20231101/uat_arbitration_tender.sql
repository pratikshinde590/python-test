-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tender`
--

DROP TABLE IF EXISTS `tender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tender` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `last_date` date NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tender`
--

LOCK TABLES `tender` WRITE;
/*!40000 ALTER TABLE `tender` DISABLE KEYS */;
INSERT INTO `tender` VALUES (6,'Hiring of Staff Car Services for a period of one year ','2023-09-20','admin/homepage_docs/tender/1694161509GeM-Bidding-5279113.pdf',1,'2023-09-08 08:25:09','2023-09-21 08:20:38'),(7,'Hiring of Manpower Services through an Outsourcing Agency','2023-09-18','admin/homepage_docs/tender/1694161576GeM-Bidding-5264349.pdf',1,'2023-09-08 08:26:16','2023-09-21 08:20:38'),(8,'Bid Cancellation Notice regarding Hiring of Staff Car (Maruti Suzuki Ciaz and MarutI Dezire)','2023-08-29','admin/homepage_docs/tender/1694161649Bid_Cancellation_Notice.pdf',1,'2023-09-08 08:27:29','2023-09-22 12:16:20'),(9,'Hiring of staff car (Maruti Suzuki Dzire) services for a period of one year','2023-10-12','admin/homepage_docs/tender/16964921721694161702GeM-Bidding-5169565-Dzire-Taxi.pdf',0,'2023-09-08 08:28:22','2023-10-05 13:21:55'),(10,'Hiring of staff car (Maruti Suzuki Ciaz) services for a period of one year','2023-08-21','admin/homepage_docs/tender/1694161786GeM-Bidding-5170532-Ciaz-Taxi.pdf',1,'2023-09-08 08:29:46','2023-10-05 18:21:14'),(11,'Engagement of Chartered Accountant firm for maintaining the accounts of IIAC initially for the period of two years','2023-03-13','admin/homepage_docs/tender/1694161838Tender-inviting-quotation-for-CA-firm.pdf',0,'2023-09-08 08:30:38','2023-09-22 12:20:43'),(14,'Bid Cancellation Notice regarding Hiring of Staff Car (Maruti Suzuki Ciaz and MarutI Dezire) New','2023-10-12','admin/homepage_docs/tender/16964923791694161702GeM-Bidding-5169565-Dzire-Taxi.pdf',1,'2023-10-05 13:22:59','2023-10-05 13:22:59'),(15,'Tender for testing agency- Test1','2023-11-17','admin/homepage_docs/tender/1698421659Zen+Python+Automation+Testing+Syllabus.pdf',0,'2023-10-27 21:17:39','2023-10-27 23:58:11'),(16,'Tender for laptops','2023-11-03','admin/homepage_docs/tender/1698432109Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-28 00:11:49','2023-10-28 00:11:49'),(17,'Tender for Electrical equipments','2023-11-04',NULL,1,'2023-10-28 00:12:25','2023-10-28 00:12:25'),(18,'Tender for Stationary ','2023-11-04',NULL,1,'2023-10-28 00:20:25','2023-10-28 00:20:25'),(19,'Tender for DIgital Electronics','2023-11-04',NULL,1,'2023-10-28 00:22:20','2023-10-28 00:22:20'),(20,'Test tender','2023-11-04',NULL,1,'2023-10-28 00:24:50','2023-10-28 00:24:50'),(21,'Test TEnder 2','2023-11-04',NULL,1,'2023-10-28 00:25:23','2023-10-28 00:25:23'),(22,'Tender for website testing agency','2024-03-07','admin/homepage_docs/tender/1698648285Shidhi_Bharti_2023_Vyapam.pdf',1,'2023-10-30 12:14:45','2023-10-30 12:14:45'),(23,'Test tender','2023-11-23','admin/homepage_docs/tender/1698829065course-listing.pdf',1,'2023-11-01 14:27:45','2023-11-01 14:27:45');
/*!40000 ALTER TABLE `tender` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:26:59
