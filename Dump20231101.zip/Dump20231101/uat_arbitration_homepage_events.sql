-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: odruat.mysql.database.azure.com    Database: uat_arbitration
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `homepage_events`
--

DROP TABLE IF EXISTS `homepage_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `venue` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `e_image_type` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `e_image_name` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `e_image_url` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `time` time NOT NULL,
  `event_url` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_events`
--

LOCK TABLES `homepage_events` WRITE;
/*!40000 ALTER TABLE `homepage_events` DISABLE KEYS */;
INSERT INTO `homepage_events` VALUES (1,'Arbitration & Dispute Resolution: Creating Conducive Business Climate','S-Block, Auditorium, 6th Floor, Delhi High Court, New Delhi','image/png','1695156232Rectangle_74.png','admin/homepage_docs/event/1695156232Rectangle_74.png','2023-04-30',1,'2023-09-20 02:13:52','2023-09-20 02:13:52','00:00:00',NULL),(2,'Python workshop event indore new','SGSITS Indore','image/png','1695838161Screenshot_2023-09-20_132330.png','admin/homepage_docs/event/1695838161Screenshot_2023-09-20_132330.png','2023-09-28',1,'2023-09-27 23:39:21','2023-10-05 15:19:59','00:00:00',NULL),(3,'Test Event','Indore','image/jpeg','1696845879image_processing20221031-6-4xw6jx.jpg','admin/homepage_docs/event/1696845879image_processing20221031-6-4xw6jx.jpg','2023-09-20',1,'2023-10-09 15:23:10','2023-10-09 15:53:57','00:00:00',NULL),(4,'Test Event','Some where','image/avif','1696847611gradient-business-party-invitation_52683-87077.avif','admin/homepage_docs/event/1696847611gradient-business-party-invitation_52683-87077.avif','2023-09-29',1,'2023-10-09 16:03:31','2023-10-09 16:03:31','00:00:00',NULL),(6,'Test','Delhi','image/jpeg','1696848292image_processing20221031-6-4xw6jx.jpg','admin/homepage_docs/event/1696848292image_processing20221031-6-4xw6jx.jpg','2030-05-04',1,'2023-10-09 16:14:52','2023-10-09 16:14:52','00:00:00',NULL),(7,'test1','Allahabad',NULL,NULL,NULL,'2023-10-13',1,'2023-10-09 16:17:20','2023-10-09 16:17:20','00:00:00',NULL),(8,'Test2','Bilaspur',NULL,NULL,NULL,'2023-10-10',1,'2023-10-09 16:18:21','2023-10-09 16:18:21','00:00:00',NULL),(9,'Inaugration Ceremony','Nagpur, India','image/jpeg','16971219170fa352fd585566ecf5c99cd7415195de.jpg','admin/homepage_docs/event/16971219170fa352fd585566ecf5c99cd7415195de.jpg','2023-11-30',1,'2023-10-12 20:15:17','2023-10-12 20:19:06','00:00:00',NULL),(10,'Test','Test','image/jpeg','16971222450fa352fd585566ecf5c99cd7415195de.jpg','admin/homepage_docs/event/16971222450fa352fd585566ecf5c99cd7415195de.jpg','2023-10-25',1,'2023-10-12 20:20:45','2023-10-16 17:41:03','00:00:00',NULL),(11,'Meeting Test Event 1','India','image/jpeg','1697458707image_processing20221031-6-4xw6jx.jpg','admin/homepage_docs/event/1697458707image_processing20221031-6-4xw6jx.jpg','2023-10-26',1,'2023-10-16 17:48:27','2023-10-16 17:48:27','00:00:00',NULL),(12,'Test','Tes','image/jpeg','16974647890fa352fd585566ecf5c99cd7415195de.jpg','admin/homepage_docs/event/16974647890fa352fd585566ecf5c99cd7415195de.jpg','2023-10-18',1,'2023-10-16 19:29:49','2023-10-16 19:29:49','00:00:00',NULL),(13,'Test Event','New Delhi','image/jpeg','1698238072download_(1).jfif','admin/homepage_docs/event/1698238072download_(1).jfif','2023-10-26',1,'2023-10-25 18:17:52','2023-10-25 18:20:35','00:00:00',NULL),(14,'Test 26th Oct','Nagpur, India','image/jpeg','16983409350fa352fd585566ecf5c99cd7415195de.jpg','admin/homepage_docs/event/16983409350fa352fd585566ecf5c99cd7415195de.jpg','2023-10-17',1,'2023-10-26 22:52:15','2023-10-26 22:52:15','00:00:00',NULL),(15,'Partyy EVent!!!!!','Delhi','image/jpeg','1698410615image_processing20221031-6-4xw6jx.jpg','admin/homepage_docs/event/1698410615image_processing20221031-6-4xw6jx.jpg','2023-11-03',1,'2023-10-27 18:13:35','2023-10-31 23:12:27','00:00:00','https://odrphase1.techdomeaks.com/admin/event'),(16,'Event Url TEst','sdfdsaf','image/jpeg','16985806491698238475profile.jpg','admin/homepage_docs/event/16985806491698238475profile.jpg','2023-11-08',1,'2023-10-29 17:27:29','2023-10-29 17:27:29','17:29:00','sdfasdf'),(17,'Fun Friday','Techdome','image/png','1698647130Screenshot_2023-10-19_at_11.08.55_AM.png','admin/homepage_docs/event/1698647130Screenshot_2023-10-19_at_11.08.55_AM.png','2023-10-30',1,'2023-10-30 11:55:30','2023-10-30 11:55:30','12:30:00','HTTPS://files/unique?page=2');
/*!40000 ALTER TABLE `homepage_events` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-01 18:22:38
